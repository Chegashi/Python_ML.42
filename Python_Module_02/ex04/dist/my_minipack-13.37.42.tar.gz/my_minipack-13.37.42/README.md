# Example Package

This is a simple example package. You can use
[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
to write your content
You can ensure whether the package was properly installed by running
the command pip list that displays the list of installed packages and
check the metadata of the package with pip show -v my_minipack. Of
course do not reproduce the exact same metadata, change the author
information, modify the summary Topic and Audience items if you want
to